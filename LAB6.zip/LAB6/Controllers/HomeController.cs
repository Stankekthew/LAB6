using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LAB6.Models;

namespace LAB6.Controllers;

public class HomeController : Controller
{
    private readonly BookDAL _dal;

    public HomeController(IConfiguration config)
    {
        _dal = new BookDAL(config);
    }

    public IActionResult Index(string search, int page = 1)
    {
        int pageSize = 5;
        List<Book> books;

        if (!string.IsNullOrEmpty(search))
        {
            books = _dal.Search(search);
        }
        else
        {
            books = _dal.GetPaged(page, pageSize);
            int totalcount =_dal.GetTotalCount();
            int totalPages = (int)Math.Ceiling(totalcount / (double)pageSize);
            ViewData["CurrentPage"] = page;
            ViewData["TotalPages"] = totalPages;
        }

        ViewData["Search"] = search;

        return View(books);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Book book)
    {
        _dal.INSERT(book);
        return RedirectToAction("Index");
    }

    public IActionResult Edit(int ID)
    {
        var book = _dal.GetByID(ID);
        return View(book);
    }

    [HttpPost]
    public IActionResult Edit(Book book)
    {
        _dal.Update(book);
        return RedirectToAction("Index");
    }

    public IActionResult Delete(int ID)
    {
         var book = _dal.GetByID(ID);
        return View(book);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int ID)
    {
        _dal.Delete(ID);
        return RedirectToAction("Index");
    }
}
