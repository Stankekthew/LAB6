using MySql.Data.MySqlClient;
using System.Collections.Generic; 

public class BookDAL
{
    private readonly string _connectionstring;

    public BookDAL(IConfiguration configuration)
    {
        _connectionstring = configuration.GetConnectionString("DefaultConnection");
    }

    public List<Book> Getall()
    {
        var list = new List<Book>();
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        var cmd = new MySqlCommand("SELECT * FROM Books", con);
        using var rdr = cmd.ExecuteReader();

        while (rdr.Read())
        {
            list.Add(new Book{
                ID = rdr.GetInt32("ID"),
                Title = rdr.GetString("Title"),
                Author = rdr.GetString("Author"),
                Year = rdr.GetInt32("Year")
            });
        }

        return list;
    }

    public Book GetByID(int ID)
    {
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        var cmd = new MySqlCommand("SELECT * FROM Books WHERE ID = @Id", con);
        cmd.Parameters.AddWithValue("@Id", ID);
        using var rdr = cmd.ExecuteReader();

        if (rdr.Read())
        {
            return new Book
            {
                ID = rdr.GetInt32("ID"),
                Title = rdr.GetString("Title"),
                Author = rdr.GetString("Author"),
                Year = rdr.GetInt32("Year")
            };
        }

        return null;
    }

    public void INSERT(Book book)
    {
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        var cmd = new MySqlCommand("INSERT INTO Books (Title, Author, Year) VALUES (@title, @author, @year)", con);
        cmd.Parameters.AddWithValue("@Title", book.Title);
        cmd.Parameters.AddWithValue("@Author", book.Author);
        cmd.Parameters.AddWithValue("@Year", book.Year);
        cmd.ExecuteNonQuery();
    }

    public void Update(Book book)
    {
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        var cmd = new MySqlCommand("UPDATE Books SET Title=@title, Author=@author, Year=@year WHERE ID=@Id,", con);
        cmd.Parameters.AddWithValue("@Title", book.Title);
        cmd.Parameters.AddWithValue("@Author", book.Author);
        cmd.Parameters.AddWithValue("@Year", book.Year);
        cmd.Parameters.AddWithValue("@ID", book.ID);
        cmd.ExecuteNonQuery();
    }

    public void Delete(int ID)
    {
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        var cmd = new MySqlCommand("DELETE FROM Books WHERE ID=@Id", con);
        cmd.Parameters.AddWithValue("@Id", ID);
        cmd.ExecuteNonQuery();
    }

    public List<Book> Search(string keyword)
    {
        var list = new List<Book>();
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        var cmd = new MySqlCommand(@"SELECT * FROM Books WHERE Title LIKE @kw OR Author LIKE @kw OR Year LIKE @kw", con);
        cmd.Parameters.AddWithValue("@kw", "%" + keyword + "%");
        using var rdr = cmd.ExecuteReader();

       while (rdr.Read())
        {
            list.Add(new Book{
                ID = rdr.GetInt32("ID"),
                Title = rdr.GetString("Title"),
                Author = rdr.GetString("Author"),
                Year = rdr.GetInt32("Year")
            });
        }

        return list;
    }

    public List<Book> GetPaged(int page, int pageSize)
    {
        var list = new List<Book>();
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        int offset = (page - 1) * pageSize;
        var cmd = new MySqlCommand("SELECT * FROM Books LIMIT @limit OFFSET @offset", con);
        cmd.Parameters.AddWithValue("@limit", pageSize);
        cmd.Parameters.AddWithValue("@offset", offset);
        using var rdr = cmd.ExecuteReader();

        while (rdr.Read())
        {
            list.Add(new Book{
                ID = rdr.GetInt32("ID"),
                Title = rdr.GetString("Title"),
                Author = rdr.GetString("Author"),
                Year = rdr.GetInt32("Year")
            });

        }
        return list;
        
    }

    public int GetTotalCount()
    {
        using var con = new MySqlConnection(_connectionstring);
        con.Open();
        var cmd = new MySqlCommand("SELECt COUNT(*) FROM Books", con);
        return Convert.ToInt32(cmd.ExecuteScalar());
    }
}

